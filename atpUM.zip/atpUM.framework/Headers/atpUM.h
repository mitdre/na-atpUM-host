#import <Foundation/Foundation.h>

@class AUMTicket, AUMStdlibArray;

@protocol AUMStdlibIterator;

NS_ASSUME_NONNULL_BEGIN

@interface KotlinBase : NSObject
-(instancetype) init __attribute__((unavailable));
+(instancetype) new __attribute__((unavailable));
+(void)initialize __attribute__((objc_requires_super));
@end;

__attribute__((objc_subclassing_restricted))
@interface AUMTicket : KotlinBase
-(instancetype)initWithTicket:(int32_t)ticket expiration:(int32_t)expiration fareType:(NSString*)fareType l:(AUMStdlibArray*)l p:(int32_t)p response:(NSString*)response responseCode:(int32_t)responseCode riderType:(NSString*)riderType routeType:(NSString*)routeType sig:(NSString*)sig sigT:(int32_t)sigT t:(int32_t)t ticketId:(int32_t)ticketId NS_SWIFT_NAME(init(ticket:expiration:fareType:l:p:response:responseCode:riderType:routeType:sig:sigT:t:ticketId:)) NS_DESIGNATED_INITIALIZER;

-(int32_t)component1 NS_SWIFT_NAME(component1());
-(int32_t)component2 NS_SWIFT_NAME(component2());
-(NSString*)component3 NS_SWIFT_NAME(component3());
-(AUMStdlibArray*)component4 NS_SWIFT_NAME(component4());
-(int32_t)component5 NS_SWIFT_NAME(component5());
-(NSString*)component6 NS_SWIFT_NAME(component6());
-(int32_t)component7 NS_SWIFT_NAME(component7());
-(NSString*)component8 NS_SWIFT_NAME(component8());
-(NSString*)component9 NS_SWIFT_NAME(component9());
-(NSString*)component10 NS_SWIFT_NAME(component10());
-(int32_t)component11 NS_SWIFT_NAME(component11());
-(int32_t)component12 NS_SWIFT_NAME(component12());
-(int32_t)component13 NS_SWIFT_NAME(component13());
-(AUMTicket*)doCopyTicket:(int32_t)ticket expiration:(int32_t)expiration fareType:(NSString*)fareType l:(AUMStdlibArray*)l p:(int32_t)p response:(NSString*)response responseCode:(int32_t)responseCode riderType:(NSString*)riderType routeType:(NSString*)routeType sig:(NSString*)sig sigT:(int32_t)sigT t:(int32_t)t ticketId:(int32_t)ticketId NS_SWIFT_NAME(doCopy(ticket:expiration:fareType:l:p:response:responseCode:riderType:routeType:sig:sigT:t:ticketId:));
@property (readonly) int32_t ticket;
@property (readonly) int32_t expiration;
@property (readonly) NSString* fareType;
@property (readonly) AUMStdlibArray* l;
@property (readonly) int32_t p;
@property (readonly) NSString* response;
@property (readonly) int32_t responseCode;
@property (readonly) NSString* riderType;
@property (readonly) NSString* routeType;
@property (readonly) NSString* sig;
@property (readonly) int32_t sigT;
@property (readonly) int32_t t;
@property (readonly) int32_t ticketId;
@end;

__attribute__((objc_subclassing_restricted))
@interface AUMStdlibArray : KotlinBase
+(instancetype)arrayWithSize:(int32_t)size init:(id _Nullable(^)(NSNumber*))init NS_SWIFT_NAME(init(size:init:));

+(instancetype)alloc __attribute__((unavailable));
+(instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));

-(id _Nullable)getIndex:(int32_t)index NS_SWIFT_NAME(get(index:));
-(id<AUMStdlibIterator>)iterator NS_SWIFT_NAME(iterator());
-(void)setIndex:(int32_t)index value:(id _Nullable)value NS_SWIFT_NAME(set(index:value:));
@property (readonly) int32_t size;
@end;

@protocol AUMStdlibIterator
@required
-(BOOL)hasNext NS_SWIFT_NAME(hasNext());
-(id _Nullable)next NS_SWIFT_NAME(next());
@end;

NS_ASSUME_NONNULL_END
